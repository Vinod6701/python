from datetime import datetime
from datetime import timedelta
import boto3, logging
from botocore.exceptions import ClientError
import os
import json


def lambda_handler(event, context):
    try:
        logger = logging.getLogger()
        logger.setLevel(logging.INFO)
        now = (datetime.now() - timedelta(days=90)).strftime("%Y-%m-%d")
        print(now)
        now = datetime.strptime(str(now),'%Y-%m-%d')
        now=now.strftime('%d-%m-%Y')
        dat=(str(now).split(" "))[0]
        rds = boto3.client('rds')
        now = datetime.now()
        flag=0
        print(now)
        print(dat)
        db_name=os.environ['DB_NAME']
        dt_string = now.strftime("%d-%m-%Y-%H-%M-%S")
        snapshot = db_name +"-snapshot-" + str(dt_string)
        print(snapshot)
        logger.info("Deleting old snapshot")
        snapshots = rds.describe_db_cluster_snapshots(
                    DBClusterIdentifier=db_name,
                    SnapshotType="manual"
                )
        for i in snapshots["DBClusterSnapshots"]:
            if str(dat) in str(i["DBClusterSnapshotIdentifier"]):
                response = rds.delete_db_cluster_snapshot(
                        DBClusterSnapshotIdentifier=i["DBClusterSnapshotIdentifier"]
                    )
                logger.info("Deleted the old snapshot taken on "+str(dat))
                flag=1
        if flag==0:
            logger.info("No older versions to delete.")
        logger.info("Creating Snapshot in progress")
        response = rds.create_db_cluster_snapshot(
            DBClusterSnapshotIdentifier=snapshot,
            DBClusterIdentifier=db_name,
            Tags=[
                {
                    'Key': 'Name',
                    'Value': snapshot
                },
                {
                    'Key': 'Project',
                    'Value': 'Evc3Depot'
                },
                {
                    'Key': 'CreatedBy',
                    'Value': 'Lambda'
                },
            ]
        )
        logger.info("Snapshot backed up successfully")
    except ClientError as e:
        return ("Unexpected error: %s" % e)
    return str(response)
